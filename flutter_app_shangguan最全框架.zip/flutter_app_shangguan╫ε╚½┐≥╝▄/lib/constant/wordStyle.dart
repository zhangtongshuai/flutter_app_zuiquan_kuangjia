import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
class WordStyles {

  static TextStyle fontSize24color333 = TextStyle(
    fontSize:ScreenUtil().setSp(24),
    color: ThemeColors.color333333,
  );

  static TextStyle fontSize24color666 = TextStyle(
    fontSize:ScreenUtil().setSp(24),
    color: ThemeColors.color666666,
  );

  static TextStyle fontSize24colorTheme = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.colorTheme,
  );

  static TextStyle fontSize24colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.colorWhite,
  );

  static TextStyle fontSize24color999 = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.color999999,
  );

  static TextStyle fontSize24colorThemeUnderline = TextStyle(
    color: ThemeColors.colorTheme,
    fontSize: ScreenUtil().setSp(24),
    decoration: TextDecoration.underline,
    decorationColor: ThemeColors.colorTheme,
  );

  static TextStyle fontSize26colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(26),
    color: ThemeColors.colorWhite,
  );

  static TextStyle fontSize26color333DecNot = TextStyle(
    fontSize: ScreenUtil().setSp(26),
    color: ThemeColors.color333333,
    decoration: TextDecoration.none,
  );

  static TextStyle fontSize28colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.colorWhite,
  );

  static TextStyle fontSize28colorTheme = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.colorTheme,
  );

  static TextStyle fontSize28color333 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color333333,
  );

  static TextStyle fontSize28color999 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color999999,
  );


  static TextStyle fontSize30colorBFBFBF = TextStyle(
    fontSize: ScreenUtil().setSp(30),
    color: ThemeColors.colorBFBFBF,
  );

  static TextStyle fontSize32colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.colorWhite,
  );

  static TextStyle fontSize32color333DecNot = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.color333333,
    decoration: TextDecoration.none,
  );

  static TextStyle fontSize32colorRed2 = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.colorRed2,
  );

  static TextStyle fontSize36colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(36),
    color: ThemeColors.colorWhite,
  );

}