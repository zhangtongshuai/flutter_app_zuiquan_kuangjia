class Api {
  static const String TERMS_SERVICE='http://img.biaoshimao.cn/content.html';//服务条款url
  static const String PRIVACY_POLICY='http://img.biaoshimao.cn/content.html';//隐私政策url
  //static const String BASE_URL = 'http://192.168.190.84:8080/mall-app';
  //static const String BASE_URL = 'http://192.168.190.84:8080';
  //static const String BASE_URL='http://192.168.190.84:8082/wx';
  static const String BASE_URL = 'http://120.25.226.11:8080//mall-app/wx';

  static const String HOME_URL=BASE_URL+'/home/index';//首页数据
  static const String REGISTER=BASE_URL+'/auth/register';//注册
  static const String LOGIN=BASE_URL+'/auth/login';//登录
  static const String LOGIN_OUT=BASE_URL+"/auth/logout";//退出登录

}
