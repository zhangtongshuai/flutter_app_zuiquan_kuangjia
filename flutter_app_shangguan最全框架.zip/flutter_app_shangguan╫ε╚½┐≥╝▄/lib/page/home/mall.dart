import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/page/home/news_page.dart';
import 'package:flutter_app_jimoshangguan/page/home/maillist_page.dart';
import 'package:flutter_app_jimoshangguan/page/home/cart_page.dart';
import 'package:flutter_app_jimoshangguan/page/home/mine_page.dart';
import 'package:flutter_app_jimoshangguan/utils/util.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';    //屏幕尺寸工具插件

class MallMainView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new MainPageState();
  }
}

class MainPageState extends State<MallMainView> {
  int _tabIndex = 0;
  var tabImages;
  var appBarTitles = [Strings.NEWS,Strings.MAILLIST,Strings.CART,Strings.MINE];
  /*
   * 存放三个页面，跟fragmentList一样
   */
  var _pageList;

  DateTime lastPopTime;

  /*
   * 根据选择获得对应的normal或是press的icon
   */
  Image getTabIcon(int curIndex) {
    if (curIndex == _tabIndex) {
      return tabImages[curIndex][1];
    }
    return tabImages[curIndex][0];
  }
  /*
   * 获取bottomTab的颜色和文字
   */
  Container getTabTitle(int curIndex) {
    if (curIndex == _tabIndex) {
      return new Container(
        margin: EdgeInsets.only(top: ScreenUtil().setWidth(5)),
        child: Text(appBarTitles[curIndex],
            style: WordStyles.fontSize24colorTheme),
      );
    } else {
      return new Container(
        margin: EdgeInsets.only(top: ScreenUtil().setWidth(5)),
        child: Text(appBarTitles[curIndex],
            style: WordStyles.fontSize24color333),
      );
    }
  }
  /*
   * 根据image路径获取图片
   */
  Image getTabImage(path) {
    return new Image.asset(path, width: ScreenUtil().setWidth(42), height: ScreenUtil().setWidth(42));
  }

  void initData() {
    /*
     * 初始化选中和未选中的icon
     */
    tabImages = [
      [getTabImage('images/news.png'), getTabImage('images/news1.png')],
      [getTabImage('images/maillist.png'), getTabImage('images/maillist1.png')],
      [getTabImage('images/cart.png'), getTabImage('images/cart1.png')],
      [getTabImage('images/my.png'), getTabImage('images/my1.png')]
    ];
    /*
     * 三个子界面
     */
    _pageList = [
      new NewsPage(),
      new MaillistPage(),
      new CartPage(),
      new MinePage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    //初始化数据
    initData();
    return Scaffold(
//        body: _pageList[_tabIndex],
        body: WillPopScope(
          onWillPop:() async{
            if(lastPopTime == null || DateTime.now().difference(lastPopTime) > Duration(seconds: 2)){
              lastPopTime = DateTime.now();
              Util.showToast(Strings.PRESS_EXIT);
            }else{
              lastPopTime = DateTime.now();
              // 退出app
              await SystemChannels.platform.invokeMethod('SystemNavigator.pop');
            }
          },
          child: _pageList[_tabIndex],
        ),
        bottomNavigationBar: new BottomNavigationBar(
          items: <BottomNavigationBarItem>[
            new BottomNavigationBarItem(
                icon: getTabIcon(0), title: getTabTitle(0)),
            new BottomNavigationBarItem(
                icon: getTabIcon(1), title: getTabTitle(1)),
            new BottomNavigationBarItem(
                icon: getTabIcon(2), title: getTabTitle(2)),
            new BottomNavigationBarItem(
                icon: getTabIcon(3), title: getTabTitle(3)),
          ],
          type: BottomNavigationBarType.fixed,
          //默认选中首页
          currentIndex: _tabIndex,
          iconSize: ScreenUtil().setSp(24),
          //点击事件
          onTap: (index) {
            setState(() {
              _tabIndex = index;
            });
          },
        ));
  }
}
