import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';

class CartPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    return layout(context);
  }

  Widget layout(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        elevation: 0.2,
        centerTitle: true,
        iconTheme: IconThemeData(),
        title: new Text(
          '购物车',
          textAlign:TextAlign.center,
          style: TextStyle(
            color: ThemeColors.color333333,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: <Widget>[
          IconButton(
              icon: Icon(
                  Icons.more_horiz,
                  color: ThemeColors.color333333
              ),
              onPressed: null
          )
        ],
        backgroundColor: ThemeColors.colorWhite,
      ),
      body: new ListView(
        children: <Widget>[

        ],
      ),
    );
  }
}

