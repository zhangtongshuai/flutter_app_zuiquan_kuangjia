import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_merchant.dart';


class MaillistPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

TextEditingController searchController = new TextEditingController();

class Page extends State<MaillistPage> {

  int _currentIndex; // 当前 页面 下标
  int _tabIndex; // 线上 /线下

  @override
  void initState() {
    super.initState();
    _currentIndex = 0;
    _tabIndex = 0;
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      backgroundColor: ThemeColors.colorWhite,
      body: new SingleChildScrollView(
        child: Column(
          children: <Widget>[
            header(context),
          ],
        ),
      ),
    );
  }

  Widget header(BuildContext context){
    return Stack(
      children: <Widget>[
        Column(
          children: <Widget>[
            Container(
                width: double.infinity,
                height: ScreenUtil().setWidth(350),
                padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30),ScreenUtil().setWidth(68), ScreenUtil().setWidth(30),0.0),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      ThemeColors.colorBtnBottom,
                      ThemeColors.colorBtnTop,
                    ],
                  ),
                ),
                child:Container(
                    alignment: Alignment.topLeft,
                    child:Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              Strings.MAILLIST,
                              style: WordStyles.fontSize36colorWhite,
                            ),
                            InkWell(
                              onTap: (){
                                print("加好友");
                              },
                              child: new Image(image: new AssetImage('images/img_m13.png'),width: ScreenUtil().setWidth(32),),
                            ),
                          ],
                        ),
                        Container(
                          margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                          child: Text(
                            '共'+'10'+'个商家，'+'11'+'个用户，'+'100'+'个好友',
                            style: WordStyles.fontSize24colorWhite,
                          ),
                        ),
                        Container(
                          height: ScreenUtil().setWidth(68),
                          margin: EdgeInsets.only(top: ScreenUtil().setWidth(30)),
                          child: new Stack(
                            alignment: Alignment(1.0, 1.0),
                            children: <Widget>[
                              new Row(
                                children: <Widget>[
                                  new Expanded(
                                      child: new TextField(
                                        cursorColor: ThemeColors.colorTheme,
                                        controller: searchController,
                                        keyboardType: TextInputType.text,
                                        scrollPadding: EdgeInsets.zero,
                                        decoration: new InputDecoration(
                                          contentPadding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
                                          isDense: true,
                                          hintText: Strings.SEARCH,
                                          hintStyle: WordStyles.fontSize28color333,
                                          border: OutlineInputBorder(borderSide: BorderSide.none,borderRadius: BorderRadius.circular(5)),
                                          prefixIcon: Icon(Icons.search),
                                          fillColor: ThemeColors.colorWhite,
                                          filled: true,
                                        ),
                                        style: WordStyles.fontSize28color333,
                                      )
                                  )
                                ],
                              ),
                            ],
                          ),
                        )
                      ],
                    )
                )
            ),
            Column(
              children: <Widget>[
                secondHeadList()
              ],
            )
          ],
        ),
        Positioned(
            top: ScreenUtil().setWidth(278),
            child: listBox()
        ),
      ],
    );
  }

  Widget listBox(){
    return Container(
      width: ScreenUtil().setWidth(690),
      margin:EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
      padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(15), 0.0, ScreenUtil().setWidth(15)),
      decoration: BoxDecoration(
          color: ThemeColors.colorWhite,
          boxShadow: [
            BoxShadow(color: Color(0x11333333), offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
          ],
          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Expanded(
            flex: 1,
            child: GestureDetector(
              onTap: (){
                setState(() {
                  _currentIndex = 0;
                });
              },
              child: Container(
                color: ThemeColors.colorWhite,
                child: Column(
                  children: <Widget>[
                    Text(
                      Strings.BUSINESS,
                      style: TextStyle(
                          color: ThemeColors.color333333,
                          fontSize: _currentIndex == 0 ? ScreenUtil().setSp(36) : ScreenUtil().setSp(32),
                          fontWeight: _currentIndex == 0 ? FontWeight.bold : FontWeight.normal
                      ),
                    ),
                    Container(
                      width: ScreenUtil().setWidth(36),
                      height: ScreenUtil().setWidth(6),
                      margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                      decoration: _currentIndex == 0 ? BoxDecoration(
                          color: ThemeColors.colorBlue,
                          boxShadow: [
                            BoxShadow(color: ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                      ):BoxDecoration(),
                    )
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child:GestureDetector(
              onTap: (){
                setState(() {
                  _currentIndex = 1;
                });
              },
              child: Container(
                color: ThemeColors.colorWhite,
                child: Column(
                  children: <Widget>[
                    Text(
                      Strings.CUSTOMER,
                      style: TextStyle(
                          fontSize: _currentIndex == 1 ? ScreenUtil().setSp(36) : ScreenUtil().setSp(32),
                          fontWeight: _currentIndex == 1 ? FontWeight.bold : FontWeight.normal
                      ),
                    ),
                    Container(
                      width: ScreenUtil().setWidth(36),
                      height: ScreenUtil().setWidth(6),
                      margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                      decoration: _currentIndex == 1 ? BoxDecoration(
                          color: ThemeColors.colorBlue,
                          boxShadow: [
                            BoxShadow(color: ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                      ):BoxDecoration(),
                    )
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: GestureDetector(
              onTap: (){
                setState(() {
                  _currentIndex = 2;
                });
              },
              child: Container(
                color: ThemeColors.colorWhite,
                child: Column(
                  children: <Widget>[
                    Text(
                      Strings.FRIEND,
                      style: TextStyle(
                          fontSize: _currentIndex == 2 ? ScreenUtil().setSp(36) : ScreenUtil().setSp(32),
                          fontWeight: _currentIndex == 2 ? FontWeight.bold : FontWeight.normal
                      ),
                    ),
                    Container(
                      width: ScreenUtil().setWidth(36),
                      height: ScreenUtil().setWidth(6),
                      margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                      decoration: _currentIndex == 2 ? BoxDecoration(
                          color: ThemeColors.colorBlue,
                          boxShadow: [
                            BoxShadow(color: ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                      ):BoxDecoration(),
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget secondHeadList(){
    return Container(
      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), ScreenUtil().setWidth(50), ScreenUtil().setWidth(30), ScreenUtil().setWidth(20)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          listBoxLeft(),
          listBoxRight()
        ],
      ),
    );
  }

  Widget listBoxLeft(){
    return Container(
      decoration: BoxDecoration(
          color: ThemeColors.colorWhite,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          GestureDetector(
            onTap: (){
              setState(() {
                _tabIndex = 0;
              });
            },
            child: Container(
              child: Column(
                children: <Widget>[
                  Text(
                    Strings.ON_LINE,
                    style: TextStyle(
                        color: ThemeColors.color333333,
                        fontSize: ScreenUtil().setSp(28),
                        fontWeight: _tabIndex == 0 ? FontWeight.bold : FontWeight.normal
                    ),
                  ),
                  Container(
                    width: ScreenUtil().setWidth(36),
                    height: ScreenUtil().setWidth(6),
                    margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                    decoration: _tabIndex == 0 ? BoxDecoration(
                        color: ThemeColors.colorBlue,
                        boxShadow: [
                          BoxShadow(color: ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                        ],
                        borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                    ):BoxDecoration(),
                  )
                ],
              ),
            ),
          ),
          SizedBox(width: ScreenUtil().setWidth(42),),
          GestureDetector(
            onTap: (){
              setState(() {
                _tabIndex = 1;
              });
            },
            child: Container(
              child: Column(
                children: <Widget>[
                  Text(
                    Strings.UNDER_LINE,
                    style: TextStyle(
                        fontSize: ScreenUtil().setSp(28),
                        fontWeight: _tabIndex == 1 ? FontWeight.bold : FontWeight.normal
                    ),
                  ),
                  Container(
                    width: ScreenUtil().setWidth(36),
                    height: ScreenUtil().setWidth(6),
                    margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                    decoration: _tabIndex == 1 ? BoxDecoration(
                        color: ThemeColors.colorBlue,
                        boxShadow: [
                          BoxShadow(color: ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                        ],
                        borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                    ):BoxDecoration(),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget listBoxRight(){
    return Container(
      decoration: BoxDecoration(
        color: ThemeColors.colorWhite,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          GestureDetector(
            onTap: (){
              setState(() {
                _tabIndex = 2;
              });
            },
            child: Container(
              child: Row(
                children: <Widget>[
                  Container(
                    width: ScreenUtil().setWidth(11),
                    height: ScreenUtil().setWidth(11),
                    color: _tabIndex == 2 ? ThemeColors.colorTheme : ThemeColors.colorWhite,
                  ),
                  SizedBox(width:ScreenUtil().setWidth(20)),
                  Text(
                    Strings.WHOLESALE,
                    style: TextStyle(
                        color: _tabIndex == 2 ? ThemeColors.colorTheme : ThemeColors.color333333,
                        fontSize: ScreenUtil().setSp(28),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(width: ScreenUtil().setWidth(42),),
          GestureDetector(
            onTap: (){
              setState(() {
                _tabIndex = 3;
              });
            },
            child: Container(
              child: Row(
                children: <Widget>[
                  Container(
                    width: ScreenUtil().setWidth(11),
                    height: ScreenUtil().setWidth(11),
                    color: _tabIndex == 3 ? ThemeColors.colorTheme : ThemeColors.colorWhite,
                  ),
                  SizedBox(width:ScreenUtil().setWidth(20) ,),
                  Text(
                    Strings.RETAIL,
                    style: TextStyle(
                        color: _tabIndex == 3 ? ThemeColors.colorTheme : ThemeColors.color333333,
                        fontSize: ScreenUtil().setSp(28),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

}

