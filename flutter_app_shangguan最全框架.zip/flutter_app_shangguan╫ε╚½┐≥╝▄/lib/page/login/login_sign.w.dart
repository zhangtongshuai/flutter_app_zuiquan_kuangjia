import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/api/api.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_app_jimoshangguan/utils/util.dart';


class LoginSignW extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

TextEditingController phoneController = new TextEditingController();
TextEditingController passController   = new TextEditingController();

class Page extends State<LoginSignW> {
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Container(
      color: ThemeColors.colorWhite,
      width: ScreenUtil().setWidth(650),
      alignment: Alignment.center,
      child: Column(
        children: <Widget>[
          LoginPhoneInput(),
          loginPassInput(),
          laymanual(),
          loginButton(context),
          loginBreif(context),
        ],
      ),
    );
  }
}


Widget LoginPhoneInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25),0.0 ,ScreenUtil().setWidth(25), 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: new InputDecoration(
                    labelText: Strings.ACCOUNT_PHONE,
                    labelStyle: WordStyles.fontSize30colorBFBFBF,
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorTheme,width: ScreenUtil().setWidth(1))
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorE6E6E6,width: ScreenUtil().setWidth(1)),
                    ),
                    prefixIcon: Icon(Icons.person),
                    fillColor: ThemeColors.colorWhite,
                    filled: true,
                  ),
                )
            )
          ],
        ),
      ],
    ),
  );
}

Widget loginPassInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25), 0.0 ,ScreenUtil().setWidth(25), 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: passController,
                  obscureText: true,
                  keyboardType: TextInputType.text,
                  decoration: new InputDecoration(
                    labelText: Strings.PASSWORD_HINT,
                    labelStyle: WordStyles.fontSize30colorBFBFBF,
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorTheme,width: ScreenUtil().setWidth(1))
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorE6E6E6,width: ScreenUtil().setWidth(1)),
                    ),
                    prefixIcon: Icon(Icons.https),
                    fillColor: ThemeColors.colorWhite,
                    filled: true,
                  ),
                )
            ),
          ],
        ),
      ],
    ),
  );
}

Widget loginButton(BuildContext context){
  return new Container(
    width:  ScreenUtil().setWidth(602),
    height: ScreenUtil().setWidth(88),
    margin: EdgeInsets.only(top: ScreenUtil().setWidth(10)),
    child: new RaisedButton(
      color: ThemeColors.colorTheme,
      splashColor: ThemeColors.colorWathet,
      elevation: 5.0,
      child: new Text(
        Strings.LOGIN,
        style: WordStyles.fontSize32colorWhite,
      ),
      onPressed: (){
        _checkSub(context);
      },
    ),
  );
}

Widget loginBreif(BuildContext context){
  return Container(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25), 0.0 ,ScreenUtil().setWidth(25), 0.0),
    margin: EdgeInsets.only(top: ScreenUtil().setWidth(19),bottom: ScreenUtil().setWidth(45) ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Container(
          child: Row(
            children: <Widget>[
              Text(
                Strings.NOT_ACCOUNT,
                style: WordStyles.fontSize28color333,
              ),
              Container(
                margin: EdgeInsets.only(left: ScreenUtil().setWidth(10)),
                child: GestureDetector(
                  onTap: (){
                    print('1111');
                    NavigatorUtils.goRegister(context);
                  },
                  child: Text(
                    Strings.GO_REGISTER,
                    style: WordStyles.fontSize28colorTheme,
                  ),
                ),
              )
            ],
          ),
        ),
        GestureDetector(
          onTap: (){
            print('2222');
            NavigatorUtils.goForget(context);
          },
          child: Text(
            Strings.FORGET_PASSWORD,
            style: WordStyles.fontSize28colorTheme,
          ),
        )
      ],
    ),
  );
}

//服务条款
void  _termsService() async{
  const url = Api.TERMS_SERVICE;
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
//隐私政策
void  _privacyPolicy() async{
  const url = Api.PRIVACY_POLICY;
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}

Widget laymanual(){
  return Container(
    padding: EdgeInsets.only(top: ScreenUtil().setWidth(60),left: ScreenUtil().setWidth(25)),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Text.rich(
          // 文字跨度（`TextSpan`）组件，不可变的文本范围。
          TextSpan(
            // 文本（`text`）属性，跨度中包含的文本。
            text: Strings.SIGN_AGREE,
            // 样式（`style`）属性，应用于文本和子组件的样式。
            style: WordStyles.fontSize24color666,
            children: [
              TextSpan(
                // 识别（`recognizer`）属性，一个手势识别器，它将接收触及此文本范围的事件。
                // 手势（`gestures`）库的点击手势识别器（`TapGestureRecognizer`）类，识别点击手势。
                recognizer: TapGestureRecognizer()..onTap = () {
                  _termsService();
                },
                text: Strings.TERMS_SERVICE,
                style: WordStyles.fontSize24colorTheme,
              ),
              TextSpan(
                text: Strings.AND,
                style: WordStyles.fontSize24color666,
              ),
              TextSpan(
                recognizer: TapGestureRecognizer()..onTap = () {
                  _privacyPolicy();
                },
                text: Strings.PRIVACY_POLICY,
                style: WordStyles.fontSize24colorTheme,
              ),
            ],
          ),
        ),
      ],
    )
  );
}

void _checkSub(BuildContext context){
  String msgStr = "";
  if(!phoneController.text.isNotEmpty ){
    msgStr = Strings.ACCOUNT_PHONE;
  }else if(!Util.isChinaPhoneLegal(phoneController.text)){
    msgStr = Strings.ACCOUNT_CORRECT_PHONE;
  }else if(!passController.text.isNotEmpty){
    msgStr = Strings.PASSWORD_HINT;
  }

  if(msgStr != ''){
    Util.showToast(msgStr);
  }else{
    NavigatorUtils.goMallMainPage(context);
  }
}

