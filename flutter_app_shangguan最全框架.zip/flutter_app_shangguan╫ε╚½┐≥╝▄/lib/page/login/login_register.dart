import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'login_widget.dart';
import 'login_register.w.dart';


class LoginRegister extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<LoginRegister> {
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      backgroundColor: ThemeColors.colorWhite,
      body: new SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: <Widget>[
              new Column(
                children: <Widget>[
                  laybox(context),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget laybox(BuildContext context){
    return Container(
      child: Stack(
        alignment:Alignment.center , //指定未定位或部分定位widget的对齐方式
        children: <Widget>[
          LoginWidget(),
          Positioned(
            top: ScreenUtil().setWidth(330),
            child: Card(
              color: ThemeColors.colorWhite,
              //z轴的高度，设置card的阴影
              elevation: 6.0,
              //设置shape，这里设置成了R角
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(6.0)),),
              //对Widget截取的行为，比如这里 Clip.antiAlias 指抗锯齿
              clipBehavior: Clip.antiAlias,
              semanticContainer: false,
              child: LoginRegisterW(),
            ),
          )
        ],
      ),
    );
  }

}

