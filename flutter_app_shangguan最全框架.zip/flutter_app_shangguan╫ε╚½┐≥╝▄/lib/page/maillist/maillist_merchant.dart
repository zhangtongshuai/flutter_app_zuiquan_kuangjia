import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

//商家通信录
class MaillistMerchant extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<MaillistMerchant> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      body: new SingleChildScrollView(
        child: Container(
          child: Column(

          ),
        ),
      ),
    );
  }



}

