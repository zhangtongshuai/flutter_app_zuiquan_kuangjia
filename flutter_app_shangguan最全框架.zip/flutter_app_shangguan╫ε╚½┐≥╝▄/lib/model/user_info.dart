import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/entity/user_entity.dart';

class UserInfoModel with ChangeNotifier {
  UserEntity userEntity;

  updateInfo(UserEntity userEntity) {
    this.userEntity = userEntity;
    notifyListeners();
  }
}
