import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/config/router_handlers.dart';

class Routers {
  static String root = "/";
  static String home = "/home";
  static String login = "/login";
  static String register = "/register";
  static String forget = "/forget";
  static String webView = "/webView";

  static void configureRoutes(Router router) {
    router.notFoundHandler = new Handler(handlerFunc:
        (BuildContext context, Map<String, List<String>> parameters) {
      print("handler not find");
      print('找不到路由，404');
    });

    router.define(root, handler: splashHandler);
    router.define(home, handler: homeHandler);
    router.define(login, handler: loginSignHandler);
    router.define(register, handler: loginRegisterHandler);
    router.define(forget, handler: loginForgetHandler);
    router.define(webView, handler: webViewHandler);
  }
}
